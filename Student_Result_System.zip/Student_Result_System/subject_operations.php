<?php
include 'conn.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['insert'])) {
        $class_id = intval($_POST['class_id']);
        $subject_name = $conn->real_escape_string($_POST['subject_name']);

        $query = "INSERT INTO subjects (class_id, subject_name) 
                  VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("is", $class_id, $subject_name);

        if ($stmt->execute()) {
            header("Location: subject_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['update'])) {
        // Update existing subject
        $subject_id = intval($_POST['subject_id']);
        $class_id = intval($_POST['class_id']);
        $subject_name = $conn->real_escape_string($_POST['subject_name']);

        $query = "UPDATE subjects 
                  SET class_id = ?, subject_name = ? 
                  WHERE subject_id = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("isi", $class_id, $subject_name, $subject_id);

        if ($stmt->execute()) {
            header("Location: subject_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} elseif (isset($_GET['subject_id'])) {
    // Delete subject
    $subject_id = intval($_GET['subject_id']);

    $query = "DELETE FROM subjects WHERE subject_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Error preparing query: " . $conn->error);
    }
    $stmt->bind_param("i", $subject_id);

    if ($stmt->execute()) {
        header("Location: subject_list.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>