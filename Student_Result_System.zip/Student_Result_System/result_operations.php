<?php
include 'conn.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $student_id = intval($_POST['student_id']);
    $subject_ids = $_POST['subject_ids'] ?? [];
    $marks = $_POST['marks'] ?? [];

    // Check if required fields are provided
    if (empty($student_id) || empty($subject_ids)) {
        die("Error: Please select a student and at least one subject.");
    }

    // Loop through each subject and insert marks into the results table
    foreach ($subject_ids as $index => $subject_id) {
        $subject_id = intval($subject_id);
        $mark = isset($marks[$index]) ? intval($marks[$index]) : 0;

        // Skip if subject_id is 0 (No Subject)
        if ($subject_id === 0) {
            continue;
        }

        // Prepare the SQL query
        $query = "INSERT INTO results (student_id, subject_id, marks_obtained) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            // Bind parameters and execute the query
            $stmt->bind_param("iii", $student_id, $subject_id, $mark);
            if (!$stmt->execute()) {
                die("Error executing query: " . $stmt->error);
            }
            $stmt->close();
        } else {
            die("Error preparing query: " . $conn->error);
        }
    }

    // Redirect to the result list page after successful insertion
    header("Location: result_list.php");
    exit();
} else {
    die("Invalid request method.");
}
?>