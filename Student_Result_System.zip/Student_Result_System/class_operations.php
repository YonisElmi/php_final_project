<?php
include 'conn.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['insert'])) {
        // Insert new class
        $class_id = intval($_POST['class_id']);
        $class_name = $conn->real_escape_string($_POST['class_name']);

        // Use prepared statements to prevent SQL injection
        $query = "INSERT INTO classes (class_id, class_name) 
                  VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("is", $class_id, $class_name);

        if ($stmt->execute()) {
            echo "Successfully registered";
            header("Location: class_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['update'])) {
        // Update existing class
        $class_id = intval($_POST['class_id']);
        $class_name = $conn->real_escape_string($_POST['class_name']);

        // Use prepared statements to prevent SQL injection
        $query = "UPDATE classes 
                  SET class_name = ? 
                  WHERE class_id = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("si", $class_name, $class_id);

        if ($stmt->execute()) {
            echo "Update successfully";
            header("Location: class_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} elseif (isset($_GET['class_id'])) {
    // Delete class
    $class_id = intval($_GET['class_id']);

    // Use prepared statements to prevent SQL injection
    $query = "DELETE FROM classes WHERE class_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Error preparing query: " . $conn->error);
    }
    $stmt->bind_param("i", $class_id);

    if ($stmt->execute()) {
        echo "Deleted successfully";
        header("Location:class_list.php"); // Redirect to the class list page
        exit(); // Ensure the script stops executing after the redirect
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Invalid request."; // Handle case where 'class_id' is not provided
}

$conn->close();
?>