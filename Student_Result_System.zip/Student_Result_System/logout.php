<?php
// Start the session (if sessions are used)
session_start();

// Destroy the session (if sessions are used)
session_destroy();

// Clear any cookies (if cookies are used)
if (isset($_COOKIE['user'])) {
    setcookie('user', '', time() - 3600, '/'); // Expire the cookie
}

// Redirect to index.html
header("Location: index.php");
exit; // Ensure no further code is executed
?>