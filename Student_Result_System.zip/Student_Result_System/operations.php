<?php
include 'conn.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['insert'])) {
        // Insert new student
        $studentId = intval($_POST['student_id']); // Ensure student_id is an integer
        $studentName = $conn->real_escape_string($_POST['student_name']); // Sanitize input
        $email = $conn->real_escape_string($_POST['email']); // Sanitize input
        $tell = $conn->real_escape_string($_POST['tell']); // Sanitize input
        $address = $conn->real_escape_string($_POST['address']); // Sanitize input
        $class_id = isset($_POST['class_id']) ? intval($_POST['class_id']) : null; // Ensure class_id is an integer

        // Use prepared statements to prevent SQL injection
        $query = "INSERT INTO students (student_id, student_name, email, tell, address, class_id) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("issssi", $studentId, $studentName, $email, $tell, $address, $class_id);

        if ($stmt->execute()) {
            echo "Successfully registered";
            header("Location: student_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['update'])) {
        // Update existing student
        $studentId = intval($_POST['student_id']); // Ensure student_id is an integer
        $studentName = $conn->real_escape_string($_POST['student_name']); // Sanitize input
        $email = $conn->real_escape_string($_POST['email']); // Sanitize input
        $tell = $conn->real_escape_string($_POST['tell']); // Sanitize input
        $address = $conn->real_escape_string($_POST['address']); // Sanitize input
        $class_id = isset($_POST['class_id']) ? intval($_POST['class_id']) : null; // Ensure class_id is an integer

        // Use prepared statements to prevent SQL injection
        $query = "UPDATE students 
                  SET student_name = ?, email = ?, tell = ?, address = ?, class_id = ? 
                  WHERE student_id = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }
        $stmt->bind_param("ssssii", $studentName, $email, $tell, $address, $class_id, $studentId);

        if ($stmt->execute()) {
            echo "Update successfully";
            header("Location: student_list.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} elseif (isset($_GET['student_id'])) {
    // Delete student
    $studentId = intval($_GET['student_id']); // Ensure student_id is an integer

    // Use prepared statements to prevent SQL injection
    $query = "DELETE FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Error preparing query: " . $conn->error);
    }
    $stmt->bind_param("i", $studentId);

    if ($stmt->execute()) {
        echo "Deleted successfully";
        header("Location: student_list.php"); // Redirect to the student list page
        exit(); // Ensure the script stops executing after the redirect
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Invalid request."; // Handle case where 'student_id' is not provided
}

$conn->close();
?>