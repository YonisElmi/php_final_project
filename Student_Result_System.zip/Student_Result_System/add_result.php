<?php
include 'conn.php'; // Include the database connection file

// Fetch students
$students_query = "SELECT Student_id, Student_name, class_id FROM students";
$students_result = $conn->query($students_query);
$students = [];
while ($row = $students_result->fetch_assoc()) {
    $students[] = $row;
}

// Fetch subjects dynamically based on student class
$selected_student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : '';
$subjects = [];

if ($selected_student_id) {
    // Fetch class ID of the selected student
    $student_query = "SELECT class_id FROM students WHERE Student_id = ?";
    $stmt = $conn->prepare($student_query);
    $stmt->bind_param("i", $selected_student_id);
    $stmt->execute();
    $stmt->bind_result($class_id);
    $stmt->fetch();
    $stmt->close();

    // Fetch subjects for the class
    $subjects_query = "SELECT subject_id, sub1, sub2, sub3, sub4 
                       FROM subjects 
                       WHERE class_id = ?";
    $stmt = $conn->prepare($subjects_query);
    $stmt->bind_param("i", $class_id);
    $stmt->execute();
    $subjects_result = $stmt->get_result();

    if ($subjects_result->num_rows > 0) {
        $row = $subjects_result->fetch_assoc();
        $subjects = [
            ['subject_id' => $row['subject_id'], 'subject_name' => $row['sub1']],
            ['subject_id' => $row['subject_id'], 'subject_name' => $row['sub2']],
            ['subject_id' => $row['subject_id'], 'subject_name' => $row['sub3']],
            ['subject_id' => $row['subject_id'], 'subject_name' => $row['sub4']],
        ];
    } else {
        // If no subjects are found, fill with "No Subject"
        $subjects = [
            ['subject_id' => 0, 'subject_name' => 'No Subject'],
            ['subject_id' => 0, 'subject_name' => 'No Subject'],
            ['subject_id' => 0, 'subject_name' => 'No Subject'],
            ['subject_id' => 0, 'subject_name' => 'No Subject'],
        ];
    }
    $stmt->close();
} else {
    // If no student is selected, fill with "No Subject"
    $subjects = [
        ['subject_id' => 0, 'subject_name' => 'No Subject'],
        ['subject_id' => 0, 'subject_name' => 'No Subject'],
        ['subject_id' => 0, 'subject_name' => 'No Subject'],
        ['subject_id' => 0, 'subject_name' => 'No Subject'],
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Marks</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .form-control {
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title text-center">Assign Marks</h4>
                    </div>
                    <div class="card-body">
                        <form action="result_operations.php" method="POST">
                            <!-- Hidden field for student ID -->
                            <input type="hidden" name="student_id" value="<?= $selected_student_id; ?>">

                            <!-- Select Student -->
                            <div class="mb-3">
                                <label for="student_id" class="form-label">Select Student</label>
                                <select name="student_id" id="student_id" class="form-select" onchange="updateSubjects()">
                                    <option value="">-- Select a Student --</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?= $student['Student_id']; ?>" <?= $selected_student_id == $student['Student_id'] ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($student['Student_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Subjects and Marks -->
                            <div class="mb-3">
                                <label class="form-label">Subjects and Marks</label>
                                <?php foreach ($subjects as $index => $subject): ?>
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input 
                                                type="checkbox" 
                                                name="subject_ids[]" 
                                                id="subject_<?= $index; ?>" 
                                                value="<?= $subject['subject_id']; ?>" 
                                                class="form-check-input" 
                                                <?= $subject['subject_id'] === 0 ? 'disabled' : ''; ?>
                                            >
                                            <label for="subject_<?= $index; ?>" class="form-check-label">
                                                <?= htmlspecialchars($subject['subject_name']); ?>
                                            </label>
                                        </div>
                                        <input 
                                            type="number" 
                                            name="marks[]" 
                                            class="form-control mt-2" 
                                            placeholder="Enter marks for <?= htmlspecialchars($subject['subject_name']); ?>" 
                                            min="0" 
                                            max="100" 
                                            <?= $subject['subject_id'] === 0 ? 'disabled' : ''; ?>
                                        >
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Buttons -->
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary" name="insert">Assign Marks</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateSubjects() {
            const studentId = document.getElementById('student_id').value;
            if (studentId) {
                window.location.href = `add_result.php?student_id=${studentId}`;
            }
        }
    </script>
</body>
</html>