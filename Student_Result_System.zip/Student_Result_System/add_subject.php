<?php
include 'conn.php'; // Ensure this file contains the database connection logic

// Fetch data if subject_id is provided for update
if (isset($_GET['subject_id'])) {
    $subject_id = intval($_GET['subject_id']);
    $query = "SELECT * FROM subjects WHERE subject_id = $subject_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $class_id = $row['class_id'];
        $sub1 = $row['sub1'];
        $sub2 = $row['sub2'];
        $sub3 = $row['sub3'];
        $sub4 = $row['sub4'];
    } else {
        echo "Subject not found.";
        exit;
    }
} else {
    $subject_id = "";
    $class_id = "";
    $sub1 = "";
    $sub2 = "";
    $sub3 = "";
    $sub4 = "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subject Registration System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-2">
            <div class="col-sm-8">
                <h2 class="text-center mt-4"><?php echo $subject_id ? 'Update' : 'Add'; ?> Subject</h2>
                <div class="card bg-light p-2 text-dark bg-opacity-10 mt-4">
                    <div class="card-body">
                        <form action="subject_operations.php" method="POST">
                            <!-- Hidden field for subject_id (only for updates) -->
                            <?php if ($subject_id): ?>
                                <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
                            <?php endif; ?>

                            <!-- Subject ID (Display only for updates) -->
                            <?php if ($subject_id): ?>
                                <div class="form-group m-2">
                                    <label for="subject_id">Subject ID</label>
                                    <input type="text" name="subject_id_display" id="subject_id_display" value="<?php echo htmlspecialchars($subject_id); ?>" class="form-control" readonly>
                                </div>
                            <?php endif; ?>

                            <!-- Class Name -->
                            <div class="form-group m-2">
                                <label for="class_id">Class Name</label>
                                <select name="class_id" id="class_id" class="form-control" required>
                                    <?php
                                    // Fetch classes from the database
                                    $query = "SELECT class_id, class_name FROM classes";
                                    $result = $conn->query($query);

                                    if ($result && $result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $selected = ($row['class_id'] == $class_id) ? "selected" : "";
                                            echo "<option value='" . htmlspecialchars($row['class_id']) . "' $selected>" . htmlspecialchars($row['class_name']) . "</option>";
                                        }
                                    } else {
                                        echo "<option value=''>No classes available</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Math Dropdown -->
                            <div class="form-group m-2">
                                <label for="sub1">Math</label>
                                <select name="sub1" id="sub1" class="form-control">
                                    <option value="math-form1" <?php echo ($sub1 == 'math-form1') ? 'selected' : ''; ?>>Math Form 1</option>
                                    <option value="math-form2" <?php echo ($sub1 == 'math-form2') ? 'selected' : ''; ?>>Math Form 2</option>
                                    <option value="math-form3" <?php echo ($sub1 == 'math-form3') ? 'selected' : ''; ?>>Math Form 3</option>
                                    <option value="math-form4" <?php echo ($sub1 == 'math-form4') ? 'selected' : ''; ?>>Math Form 4</option>
                                </select>
                            </div>

                            <!-- Physics Dropdown -->
                            <div class="form-group m-2">
                                <label for="sub2">Physics</label>
                                <select name="sub2" id="sub2" class="form-control">
                                    <option value="physics-form1" <?php echo ($sub2 == 'physics-form1') ? 'selected' : ''; ?>>Physics Form 1</option>
                                    <option value="physics-form2" <?php echo ($sub2 == 'physics-form2') ? 'selected' : ''; ?>>Physics Form 2</option>
                                    <option value="physics-form3" <?php echo ($sub2 == 'physics-form3') ? 'selected' : ''; ?>>Physics Form 3</option>
                                    <option value="physics-form4" <?php echo ($sub2 == 'physics-form4') ? 'selected' : ''; ?>>Physics Form 4</option>
                                </select>
                            </div>

                            <!-- Chemistry Dropdown -->
                            <div class="form-group m-2">
                                <label for="sub3">Chemistry</label>
                                <select name="sub3" id="sub3" class="form-control">
                                    <option value="chemistry-form1" <?php echo ($sub3 == 'chemistry-form1') ? 'selected' : ''; ?>>Chemistry Form 1</option>
                                    <option value="chemistry-form2" <?php echo ($sub3 == 'chemistry-form2') ? 'selected' : ''; ?>>Chemistry Form 2</option>
                                    <option value="chemistry-form3" <?php echo ($sub3 == 'chemistry-form3') ? 'selected' : ''; ?>>Chemistry Form 3</option>
                                    <option value="chemistry-form4" <?php echo ($sub3 == 'chemistry-form4') ? 'selected' : ''; ?>>Chemistry Form 4</option>
                                </select>
                            </div>

                            <!-- Biology Dropdown -->
                            <div class="form-group m-2">
                                <label for="sub4">Biology</label>
                                <select name="sub4" id="sub4" class="form-control">
                                    <option value="biology-form1" <?php echo ($sub4 == 'biology-form1') ? 'selected' : ''; ?>>Biology Form 1</option>
                                    <option value="biology-form2" <?php echo ($sub4 == 'biology-form2') ? 'selected' : ''; ?>>Biology Form 2</option>
                                    <option value="biology-form3" <?php echo ($sub4 == 'biology-form3') ? 'selected' : ''; ?>>Biology Form 3</option>
                                    <option value="biology-form4" <?php echo ($sub4 == 'biology-form4') ? 'selected' : ''; ?>>Biology Form 4</option>
                                </select>
                            </div>

                            <!-- Buttons -->
                            <div class="form-group m-2">
                                <?php if ($subject_id): ?>
                                    <button type="submit" class="btn btn-secondary m-2" name="update">Update</button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-info m-2" name="insert">Register</button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>