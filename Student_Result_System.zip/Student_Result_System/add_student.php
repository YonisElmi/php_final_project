<?php
include 'conn.php'; // Ensure this file contains the database connection logic

// Fetch data if student_id is provided for update
if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];
    $student_name = isset($_GET['student_name']) ? $_GET['student_name'] : ''; // Check if key exists
    $email = isset($_GET['email']) ? $_GET['email'] : ''; // Check if key exists
    $tell = isset($_GET['tell']) ? $_GET['tell'] : ''; // Check if key exists
    $address = isset($_GET['address']) ? $_GET['address'] : ''; // Check if key exists
    $class_id = isset($_GET['class_id']) ? $_GET['class_id'] : ''; // Fetch class_id from the URL
} else {
    $student_id = "";
    $student_name = "";
    $email = "";
    $tell = "";
    $address = "";
    $class_id = ""; // Initialize class_id
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-2">
            <div class="col-sm-8">
                <h2 class="text-center mt-4">add Student</h2>
                <div class="card bg-light p-2 text-dark bg-opacity-10 mt-4">
                    <div class="card-body">
                        <form action="operations.php" method="POST">
                            <!-- Student ID -->
                            <div class="form-group m-2">
                                <label for="student_id">Student ID</label>
                                <input type="text" name="student_id" id="student_id" value="<?php echo htmlspecialchars($student_id); ?>" class="form-control">
                            </div>

                            <!-- Student Name -->
                            <div class="form-group m-2">
                                <label for="student_name">Student Name</label>
                                <input type="text" name="student_name" id="student_name" value="<?php echo htmlspecialchars($student_name); ?>" class="form-control">
                            </div>

                            <!-- Email -->
                            <div class="form-group m-2">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email); ?>" class="form-control">
                            </div>

                            <!-- Phone -->
                            <div class="form-group m-2">
                                <label for="tell">Phone</label>
                                <input type="text" name="tell" id="tell" value="<?php echo htmlspecialchars($tell); ?>" class="form-control">
                            </div>

                            <!-- Address -->
                            <div class="form-group m-2">
                                <label for="address">Address</label>
                                <input type="text" name="address" id="address" value="<?php echo htmlspecialchars($address); ?>" class="form-control">
                            </div>

                            <!-- Class Name -->
                            <div class="form-group m-2">
    <label for="class_id">Class Name</label>
    <select name="class_id" id="class_id" class="form-control">
        <?php
        // Fetch classes from the database
        $query = "SELECT class_id, class_name FROM classes";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Check if the current class_id matches the one passed in the URL
                $selected = ($row['class_id'] == $class_id) ? "selected" : "";
                echo "<option value='" . htmlspecialchars($row['class_id']) . "' $selected>" . htmlspecialchars($row['class_name']) . "</option>";
            }
        } else {
            echo "<option value=''>No classes available</option>";
        }
        ?>
    </select>
</div>

                            <!-- Buttons -->
                            <div class="form-group m-2">
                                <button type="submit" class="btn btn-info m-2" name="insert">Register</button>
                                <button type="submit" class="btn btn-secondary m-2" name="update">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>