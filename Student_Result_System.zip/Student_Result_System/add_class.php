<?php
include 'conn.php'; // Include the database connection file

// Fetch data if class_id is provided for update
if (isset($_GET['class_id'])) {
    $class_id = intval($_GET['class_id']);
    $class_name = isset($_GET['class_name']) ? $conn->real_escape_string($_GET['class_name']) : '';
} else {
    $class_id = "";
    $class_name = "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-2">
            <div class="col-sm-8">
                <h2 class="text-center mt-4">Add Class</h2>
                <div class="card bg-light p-2 text-dark bg-opacity-10 mt-4">
                    <div class="card-body">
                        <form action="class_operations.php" method="POST">
                            <!-- Class ID -->
                            <div class="form-group m-2">
                                <label for="class_id">Class ID</label>
                                <input type="text" name="class_id" id="class_id" value="<?php echo htmlspecialchars($class_id); ?>" class="form-control" required>
                            </div>

                            <!-- Class Name -->
                            <div class="form-group m-2">
                                <label for="class_name">Class Name</label>
                                <input type="text" name="class_name" id="class_name" value="<?php echo htmlspecialchars($class_name); ?>" class="form-control" required>
                            </div>

                            <!-- Buttons -->
                            <div class="form-group m-2">
                                <?php if ($class_id): ?>
                                    <button type="submit" class="btn btn-secondary m-2" name="update">Update</button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-info m-2" name="insert">Register</button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>